#ifndef CONFLICTRES_H
#define CONFLICTRES_H

#include "Operator.h"
#include "Trm.h"
#include "Expression.h"
#include "Tokenizer.h"

#endif
