Instructions for CSE655 - Lab 1:
1. The code has been written in C++;
2. The platform is: stdsun;
3. It can be compiled using the below command:
	g++ -o Tokenizer Tokenizer.cpp
4. The compiled program can be executed as below:
	./Tokenizer <<input file name>>
5. The output is displayed on the standard screen.
